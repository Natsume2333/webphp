<?php
namespace app\union\controller;

use think\Validate;
use cmf\controller\UnionBaseController;
use app\union\model\UserModel;

class PersonalController extends UnionBaseController
{
    //首页数据
    public function home(){

      $id = session('union.id');
        $guild_join_list = db('guild_join')->where('status=1 and guild_id='.$id)->select();
        //总人数
        $guild_info['num'] = count($guild_join_list);
        $user_id_list = [];
        //总收益
        foreach ($guild_join_list as $v) {
            $user_id_list[] = $v['user_id'];
        }
        $guild_info['total_income'] = db('user_consume_log')->where('to_user_id', 'in', $user_id_list)->count('profit');

        $day_time = strtotime(date("Y-m-d",time()));

        //今日总收益
        $guild_info['day_income'] = db('user_consume_log')
            ->where('create_time', '>', $day_time)->where('to_user_id', 'in', $user_id_list)->count('profit');

        $guild_info['auditing_num'] = db('guild_join')->where('id=' . $id . ' and status=0')->count();
        //总人数
        $guild_info['num'] = db('guild_join')->where('guild_id=' . $id . ' and status=1')->count();

        $this->assign('list', $guild_info);
        return $this->fetch();
		
    }
    //个人资料
	public function index(){
		$id = session('union.id');
		$where='id=' . $id;
        $list = db('guild')->where($where)->find();
        $this->assign('list', $list);
		return $this->fetch();
	}
	//保存个人资料
	public function add_index(){
		$id = session('union.id');
        $name=input("name");
        $introduce=input("introduce");
        $logo   = input("logo");
        $tel   = input("tel");
        $psd   = input("psd");

        if(empty($name)){
           $this->error('昵称不能为空');
        }
        if(empty($introduce)){
            $this->error('请输入简介');
        }
         if(empty($tel)){
            $this->error('请输入手机号');
        }
        if(empty($logo)){
            $this->error('请上传头像');
        }

        $data=array(
            'name'=>$name,
            'introduce'=>$introduce,
            'logo'=>$logo,
            'tel'=>$tel,
        );
        if(!empty($psd)){
            if(strlen($psd) < 6){
                $this->error("请输入密码6位以上的密码");
            }else{
                $data['psd']=cmf_password($psd);
            }
        }

        $requery=db('guild')->where('id ='.$id)->update($data);
        if($requery){
            $this->success('保存成功');
        }else{
             $this->error('保存失败');
        }
	}

}

?>